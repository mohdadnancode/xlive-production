import { useEffect } from "react";
import { CheckCircle, X } from "lucide-react";
import "./ContactPage.css";

export default function SuccessModal({ isOpen, onClose, userName }) {
  // Lock body scroll & close on Escape
  useEffect(() => {
    if (!isOpen) return;
    document.body.style.overflow = "hidden";
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div
        className="modal-container"
        onClick={(e) => e.stopPropagation()}
      >
        {/* HUD Corners */}
        <span className="modal-hud-tl" />
        <span className="modal-hud-tr" />
        <span className="modal-hud-bl" />
        <span className="modal-hud-br" />

        {/* Scanline overlay */}
        <div className="modal-scanlines" />

        {/* Close button */}
        <button
          className="modal-close-btn"
          onClick={onClose}
          aria-label="Close modal"
        >
          <X size={18} strokeWidth={2.2} />
        </button>

        {/* Animated checkmark */}
        <div className="modal-icon-wrap">
          <div className="modal-icon-ring" />
          <CheckCircle size={48} strokeWidth={1.5} />
        </div>

        {/* Content */}
        <div className="modal-eyebrow">// Transmission Sent</div>
        <h3 className="modal-title">
          <span className="modal-title-ghost">MESSAGE</span>
          <em>RECEIVED</em>
        </h3>
        <p className="modal-body">
          {userName ? (
            <>
              Thank you, <span className="modal-highlight">{userName}</span>.
            </>
          ) : (
            "Thank you."
          )}{" "}
          Your message has been successfully transmitted to our operations center. Our team will respond within 24 hours.
        </p>

        {/* CTA */}
        <button className="modal-cta btn-race" onClick={onClose}>
          ROGER THAT ›
        </button>

        {/* Bottom tag */}
        <div className="modal-status">
          <span className="modal-status-dot" />
          STATUS: DELIVERED
        </div>
      </div>
    </div>
  );
}
